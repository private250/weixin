//
//  main.m
//  testWeiXinPost
//
//  Created by EasonWang on 13-11-1.
//  Copyright (c) 2013年 EasonWang. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *body = @"<xml>"
        "<ToUserName>easonwzs@126.com</ToUserName>"
        "<FromUserName>easonwzs</FromUserName>"
        "<CreateTime>12345678</CreateTime>"
        "<MsgType>text</MsgType>"
        "<Content>ap</Content>"
        "</xml>";
        
        NSString *httpStr = @"http://192.168.0.65:8080/WeiXinTest/CoreServlet";
        NSURL *httpUrl = [NSURL URLWithString:httpStr];
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:httpUrl];
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
        
        NSURLResponse *response = nil;
        
        NSData* mData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:nil];
        

        NSString *xml ;
        if (mData != nil) {
            xml = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding] ;
            xml = [xml stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
            xml = [xml stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
            xml = [xml stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
            NSLog(@"%@", xml);
        }
    }
    return 0;
}

